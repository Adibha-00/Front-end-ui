This folder contains configuration files which may be useful for developers.
Almost certainly, none of these files will work from their current location. You may need to symlink them to a more useful location.
